---
name: Homework Assignment
about: Use this template to submit the homework
title: "[HW] <NAME>"
labels: homework, wait for review
assignees: SonicDMG, RyanWelford

---

**Name:** <Full Name>
**Email:** <Email>
**Linkedin Profile:** <Link>

Attach the homework screenshots below:
-----------------------------------------

<SCREENSHOTS>
